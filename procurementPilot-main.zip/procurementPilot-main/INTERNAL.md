# Challenge Questions for the Interview
1. Sycophancy: You are now using an LLM Wrapper, for the same task of risk assessment. The LLM wrapper gets all engineered features but procurement specialists insist: “We have unique intuition about risky     POs.” Should this be incorporated? How?
   A: Human intuition is valuable but must be structured. LLMs are vulnerable to !sycophancy!, meaning they may over-agree with human opinions even when wrong.
   You could include experts in the model design / feature selection. Their intuition in form of what is important for the decision, will be captured and the experts will feel heard
2. Share your thoughts on how you would create a human-feedback loop without reinforcing bias?
   A: - multiple experts give feedback, great difference: example is not used for model improvement
      - Bias checks: regular checks assess whether certain regions, suppliers etc. are flagged as risk way more often than others
      - etc.
3. How would you balance the Precision Recall trade-off from a business point of view in our case? You are talking to Procurement and Production.
   Procurement --> wants high precision (few false alarms --> less unnecessary escalation)
   Production --> wants high recall (no missed risks, no production downtime)
4. The applicant will send the notebook in advance. If he did not do it himself, we should draw the Precision Recall curve and see / ask what is the "optimal" choice of parameters.
5. "I trained a model myself and my accuracy is actually higher than yours, based on that information, do you think you can still compete based on predictive power"
   An: Yes, Accuracy is always misleading in a highly imbalanced data set. Not a good way to measure a model.
6. How much of a problem is bilinguality in the data set
   A: It definitely reduces performance. You should train on a multilingual sentence transformer. Did they? (We gonna make some research on the model they used and see whether they are right. It is             important to know the model you used, what its typically used for etc.)
7. Is it possible to know why the model made a decision? If so, how?
   A: SHAP for structured features, LIME for text features, Top predictive features ranked, etc. BUT: depends on the model they used
8. Should the system run in real-time or batches?
   A: Depends on the company, especially on the communication with the suppliers, with having "only" 5.000 POs in 1 year of time, we only have about 25 POs a day --> daily batch is enough. Costs are higher.
9. Do you think that a Foundation Model with the same features as input will outperform your solution?
   A: Best case, it is improved and fine tuned when used, and gets better by time. Specialized models should outperform generalized models and are way more cost efficient. (Any answer is valid as long as it    is interesting)
   


Remark: We are aware that these data are synthezied and therefore might not reflect real life behavior. Therefore you can expect us to challenge you on the methods and metrics you used based on assumptions that you can make, but should clearly explain in your presentation. Higher score does not necissarily your way of solving the problem is better and other way around.

